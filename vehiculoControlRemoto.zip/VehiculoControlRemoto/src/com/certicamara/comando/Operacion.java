package com.certicamara.comando;

/**
 * 
 * @author Carolina Mateus
 *
 */
public interface Operacion {
	void ejecutar();
}